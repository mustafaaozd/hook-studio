import {createClient} from 'npm:@supabase/supabase-js@2.95.0';
const SITE='https://mustafaaozd.github.io/hook-studio/';
const ORIGIN=new URL(SITE).origin;
const cors={'Access-Control-Allow-Origin':ORIGIN,'Access-Control-Allow-Headers':'authorization, apikey, content-type, x-report-token','Access-Control-Allow-Methods':'GET, POST, PATCH, DELETE, OPTIONS','Vary':'Origin','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const fail=(status:number,message:string):never=>{throw Object.assign(new Error(message),{status})};
const text=(v:unknown,max=200)=>typeof v==='string'&&v.length<=max?v:fail(400,'Geçersiz bilgi.');
const uuid=(v:unknown)=>typeof v==='string'&&/^[a-f0-9-]{36}$/i.test(v)?v:fail(400,'Geçersiz kimlik.');
const digest=async(v:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(v))),x=>x.toString(16).padStart(2,'0')).join('');
const random=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),x=>x.toString(16).padStart(2,'0')).join('');
const result=async(q:any)=>{const {data,error}=await q;if(error)throw error;return data};
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:cors});
Deno.serve(async(req:Request)=>{
 if(req.method==='OPTIONS')return new Response(null,{status:204,headers:cors});
 try{
  const client=createClient(Deno.env.get('SUPABASE_URL')!,Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,{auth:{persistSession:false,autoRefreshToken:false}});
  const bucket=client.storage.from('hook-studio-media');
  const brands=()=>client.from('hook_studio_brands');const items=()=>client.from('hook_studio_items');
  const url=new URL(req.url),path=url.searchParams.get('path')||'data',parts=path.split('/');
  const token=req.headers.get('x-report-token');let admin=false,shared:any=null;
  if(token){if(!/^[a-f0-9]{64}$/.test(token))fail(403,'Bağlantı geçerli değil.');shared=await result(brands().select('id,name,logo,description,created').eq('token',await digest(token)).maybeSingle());}
  else{const jwt=req.headers.get('Authorization')?.replace(/^Bearer /i,'');if(jwt){const {data,error}=await client.auth.getUser(jwt);if(!error&&data.user&&!data.user.is_anonymous)admin=!!await result(client.from('hook_studio_admins').select('user_id').eq('user_id',data.user.id).maybeSingle());}}
  if(!admin&&!shared)fail(403,'Yönetici girişi veya geçerli müşteri bağlantısı gerekiyor.');
  if(req.method!=='GET'&&!admin)fail(403,'Yalnızca yönetici düzenleyebilir.');
  if(req.method!=='GET'&&req.headers.get('origin')!==ORIGIN)fail(403,'Geçersiz istek kaynağı.');
  if(path==='data'&&req.method==='GET'){
   const bs=admin?await result(brands().select('id,name,logo,description,created').order('created')):[shared];
   let q=items().select('*').order('position');if(!admin)q=q.eq('brand_id',shared.id);
   const rows=await result(q);const keys=[...new Set(rows.flatMap((v:any)=>admin?[v.original,v.clip]:[v.kind==='ad'?v.original:v.clip]))] as string[];
   const signed=keys.length?await result(bucket.createSignedUrls(keys,600)):[];
   const links=new Map(signed.map((s:any)=>[s.path,s.signedUrl]));
   return json({admin,brands:bs,videos:rows.map((v:any)=>{const {original,clip,...safe}=v;return {...safe,clip,original_url:admin||v.kind==='ad'?links.get(original):undefined,clip_url:links.get(clip)}})});
  }
  if(path==='share'){
   if(!admin)fail(403,'Yalnızca yönetici.');const body=req.method==='GET'?{id:url.searchParams.get('id')}:await req.json();
   const b=await result(brands().select('id,share_key').eq('id',uuid(body.id)).maybeSingle());if(!b)fail(404,'Marka bulunamadı.');
   let key=b.share_key;
   if(req.method==='POST'&&(!key||body.rotate)){key=random();await result(brands().update({token:await digest(key),share_key:key}).eq('id',b.id));}
   else if(req.method!=='POST'&&req.method!=='GET')fail(405,'Geçersiz işlem.');
   return json({url:key?SITE+'#r='+key:''});
  }
  if(path==='brands'&&req.method==='POST'){
   const b=await req.json(),name=text(b.name).trim(),logo=text(b.logo||'',1500000),description=text(b.description||'',1000);
   if(!name||logo&&!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(logo))fail(400,'Marka adı ve logosunu kontrol edin.');
   const data={name,logo,description};if(b.id){await result(brands().update(data).eq('id',uuid(b.id)));return json({id:b.id});}
   const row=await result(brands().insert(data).select('id').single());return json(row);
  }
  if(path==='brands'&&req.method==='DELETE'){
   const b=await req.json(),id=uuid(b.id);const rows=await result(items().select('original,clip').eq('brand_id',id));
   const keys=[...new Set(rows.flatMap((v:any)=>[v.original,v.clip]))] as string[];
   for(let n=0;n<keys.length;n+=100)await result(bucket.remove(keys.slice(n,n+100)));
   await result(brands().delete().eq('id',id));return json({ok:true});
  }
  if(path==='reorder'&&req.method==='POST'){
   const b=await req.json();if(!Array.isArray(b.ids)||b.ids.length>2000)fail(400,'Geçersiz sıra.');
   await result(client.rpc('hook_studio_reorder',{b:uuid(b.brand),k:b.kind,ids:b.ids.map(uuid)}));return json({ok:true});
  }
  if(parts[0]==='videos'&&req.method==='POST'){
   if(Number(req.headers.get('content-length')||0)>105*1024*1024)fail(413,'Dosya çok büyük.');
   const f=await req.formData(),recut=parts.length===3&&parts[2]==='clip';
   const old=recut?await result(items().select('*').eq('id',uuid(parts[1])).maybeSingle()):null;
   if(recut&&(!old||old.kind!=='hook'))fail(404,'Kanca bulunamadı.');
   const kind=recut?'hook':text(f.get('kind')),performance=kind==='ad'?text(f.get('performance')):'';
   const name=text(f.get('name')).trim(),hook=kind==='ad'?0:Number(f.get('hook')),start=kind==='ad'?0:Number(f.get('start')),end=Number(f.get('end'));
   const original=f.get('original'),clip=kind==='ad'?original:f.get('clip');
   const image=!recut&&original instanceof File&&['image/png','image/jpeg','image/webp'].includes(original.type);
   if(!['hook','ad'].includes(kind)||kind==='ad'&&!['cok_iyi','iyi','ortalama'].includes(performance)||!name||![hook,start,end].every(Number.isFinite)||hook<0||hook>100||start<0||end<start||kind==='hook'&&(end<=start||end-start>60.1))fail(400,'İçerik bilgilerini kontrol edin.');
   const validate=(v:unknown,isImage=false)=>{if(!(v instanceof File)||!v.size||v.size>(isImage?10:50)*1024*1024||!(isImage?['image/png','image/jpeg','image/webp']:['video/mp4','video/webm','video/quicktime']).includes(v.type))fail(400,'Dosya biçimi veya boyutu uygun değil.');return v as File};
   if(!recut)validate(original,image);validate(clip,image);if(image&&kind!=='ad')fail(400,'Görsel yalnızca reklamlara eklenebilir.');
   if(image){const h=new Uint8Array(await (original as File).slice(0,12).arrayBuffer());const mime=(original as File).type;const ok=mime==='image/png'?h[0]===137&&h[1]===80&&h[2]===78&&h[3]===71:mime==='image/jpeg'?h[0]===255&&h[1]===216&&h[2]===255:String.fromCharCode(...h.slice(0,4))==='RIFF'&&String.fromCharCode(...h.slice(8,12))==='WEBP';if(!ok)fail(400,'Geçersiz görsel.');}
   const brand=recut?old.brand_id:uuid(f.get('brand'));if(!await result(brands().select('id').eq('id',brand).maybeSingle()))fail(404,'Marka bulunamadı.');
   const id=recut?old.id:crypto.randomUUID(),root=brand+'/'+id+'/',okey=recut?old.original:root+'original',ckey=kind==='ad'?okey:root+'clip-'+crypto.randomUUID();
   const uploaded:string[]=[];
   try{
    if(!recut){await result(bucket.upload(okey,original as File,{contentType:(original as File).type}));uploaded.push(okey);}
    if(kind==='hook'){await result(bucket.upload(ckey,clip as File,{contentType:(clip as File).type}));uploaded.push(ckey);}
    if(recut)await result(items().update({name,hook,start,end,clip:ckey}).eq('id',id));
    else await result(items().insert({id,brand_id:brand,name,hook,start,end,original:okey,clip:ckey,kind,performance,media_type:image?'image':'video',position:Date.now()}));
   }catch(e){if(uploaded.length)await bucket.remove(uploaded);throw e;}
   if(recut&&old.clip!==old.original)await result(bucket.remove([old.clip]));return json({id});
  }
  if(path==='videos'&&(req.method==='PATCH'||req.method==='DELETE')){
   const b=await req.json(),id=uuid(b.id),v=await result(items().select('*').eq('id',id).maybeSingle());if(!v)fail(404,'İçerik bulunamadı.');
   if(req.method==='DELETE'){await result(bucket.remove([...new Set([v.original,v.clip])]));await result(items().delete().eq('id',id));}
   else{const name=text(b.name).trim(),hook=v.kind==='ad'?0:Number(b.hook),performance=v.kind==='ad'?text(b.performance):'';if(!name||!Number.isFinite(hook)||hook<0||hook>100||v.kind==='ad'&&!['cok_iyi','iyi','ortalama'].includes(performance))fail(400,'Bilgileri kontrol edin.');await result(items().update({name,hook,performance}).eq('id',id));}
   return json({ok:true});
  }
  fail(404,'İşlem bulunamadı.');
 }catch(e:any){console.error('Hook Studio request failed',e.status||500,e.code||'');return json({error:e.status?e.message:'İşlem tamamlanamadı. Lütfen yeniden deneyin.'},e.status||500)}
});
