-- Isolated Hook Studio tables. No changes to existing Meta tables or policies.
create table public.hook_studio_admins (user_id uuid primary key references auth.users(id) on delete cascade);
create table public.hook_studio_brands (
 id uuid primary key default gen_random_uuid(), name text not null check(length(name) between 1 and 200),
 logo text not null default '', description text not null default '',
 token text unique, share_key text, created timestamptz not null default now()
);
create table public.hook_studio_items (
 id uuid primary key default gen_random_uuid(), brand_id uuid not null references public.hook_studio_brands(id) on delete cascade,
 name text not null check(length(name) between 1 and 200), hook numeric not null default 0 check(hook between 0 and 100),
 original text not null, clip text not null, start numeric not null default 0, "end" numeric not null default 0,
 kind text not null check(kind in ('hook','ad')), performance text not null default '',
 media_type text not null check(media_type in ('image','video')), position double precision not null default 0,
 created timestamptz not null default now(), check(start>=0 and "end">=start)
);
create index hook_studio_items_brand_order on public.hook_studio_items(brand_id,kind,position);
alter table public.hook_studio_admins enable row level security;
alter table public.hook_studio_brands enable row level security;
alter table public.hook_studio_items enable row level security;
revoke all on public.hook_studio_admins, public.hook_studio_brands, public.hook_studio_items from public,anon,authenticated;
grant all on public.hook_studio_admins, public.hook_studio_brands, public.hook_studio_items to service_role;
create function public.hook_studio_reorder(b uuid,k text,ids uuid[]) returns void
language plpgsql security invoker set search_path='' as $$
begin
 perform 1 from public.hook_studio_brands where id=b for update;
 if k not in ('hook','ad') or cardinality(ids)<> (select count(distinct x) from unnest(ids) x)
 or exists(select id from public.hook_studio_items where brand_id=b and kind=k except select unnest(ids))
 or exists(select unnest(ids) except select id from public.hook_studio_items where brand_id=b and kind=k)
 then raise exception 'Content changed; reload before reordering'; end if;
 update public.hook_studio_items i set position=s.n from unnest(ids) with ordinality s(id,n)
 where i.id=s.id and i.brand_id=b and i.kind=k;
end $$;
revoke all on function public.hook_studio_reorder(uuid,text,uuid[]) from public,anon,authenticated;
grant execute on function public.hook_studio_reorder(uuid,text,uuid[]) to service_role;
insert into storage.buckets(id,name,public,file_size_limit,allowed_mime_types)
 values('hook-studio-media','hook-studio-media',false,52428800,array['image/png','image/jpeg','image/webp','video/mp4','video/webm','video/quicktime']);
