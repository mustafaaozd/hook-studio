type AudioGraph={context:AudioContext;destination:MediaStreamAudioDestinationNode};
const graphs=new WeakMap<HTMLVideoElement,AudioGraph>();
export async function cutVideo(video:HTMLVideoElement,start:number,end:number,progress:(s:string)=>void):Promise<Blob>{
 if(!Number.isFinite(start)||!Number.isFinite(end)||!Number.isFinite(video.duration)||start<0||end<=start||end>video.duration+.05||end-start>60)throw new Error('Videodan en fazla 60 saniyelik bir aralık seçin. Örneğin 4–7 saniye = 3 saniye.');
 if(typeof MediaRecorder==='undefined'||!HTMLCanvasElement.prototype.captureStream)throw new Error('Bu tarayıcı video kesmeyi desteklemiyor. Güncel Safari, Chrome veya Edge kullanın.');
 const mime=['video/mp4','video/webm;codecs=vp8,opus','video/webm'].find(t=>MediaRecorder.isTypeSupported(t));if(!mime)throw new Error('Bu tarayıcıda desteklenen video kayıt biçimi bulunamadı.');
 progress('Video hazırlanıyor…');video.pause();
 let graph=graphs.get(video);
 if(!graph){const AudioCtor=window.AudioContext||(window as any).webkitAudioContext;if(!AudioCtor)throw new Error('Tarayıcının ses işleme desteği yok.');const context:AudioContext=new AudioCtor(),source=context.createMediaElementSource(video),destination=context.createMediaStreamDestination();source.connect(destination);source.connect(context.destination);graph={context,destination};graphs.set(video,graph)}
 await graph.context.resume();
 const audioGraph=graph;
 video.currentTime=start;
 await new Promise<void>((resolve,reject)=>{if(!video.seeking){resolve();return}const timeout=setTimeout(()=>{video.removeEventListener('seeked',done);reject(new Error('Video konumlandırılamadı. Tekrar deneyin.'))},10000);function done(){clearTimeout(timeout);resolve()}video.addEventListener('seeked',done,{once:true})});
 const canvas=document.createElement('canvas'),scale=Math.min(1,1080/Math.max(video.videoWidth,video.videoHeight));canvas.width=Math.max(2,Math.round(video.videoWidth*scale/2)*2);canvas.height=Math.max(2,Math.round(video.videoHeight*scale/2)*2);
 const context=canvas.getContext('2d');if(!context)throw new Error('Video işleme başlatılamadı.');
 context.drawImage(video,0,0,canvas.width,canvas.height);
 const stream=canvas.captureStream(30);
 audioGraph.destination.stream.getAudioTracks().forEach(track=>stream.addTrack(track.clone()));
 const recorder=new MediaRecorder(stream,{mimeType:mime,videoBitsPerSecond:4000000});
 return new Promise<Blob>((resolve,reject)=>{
  let stopped=false,raf=0,timer:ReturnType<typeof setInterval>,timeout:ReturnType<typeof setTimeout>;const chunks:BlobPart[]=[];let failure:Error|null=null;
  const cleanup=()=>{video.pause();cancelAnimationFrame(raf);clearInterval(timer);clearTimeout(timeout);stream.getTracks().forEach(t=>t.stop());void audioGraph.context.suspend()};
  const stop=(error?:Error)=>{if(stopped)return;stopped=true;failure=error||null;video.pause();if(recorder.state!=='inactive')recorder.stop();else{cleanup();reject(failure||new Error('Video kaydı başlayamadı.'))}};
  function draw(){if(stopped)return;context!.drawImage(video,0,0,canvas.width,canvas.height);raf=requestAnimationFrame(draw)}
  recorder.ondataavailable=e=>{if(e.data.size)chunks.push(e.data)};
  recorder.onerror=()=>stop(new Error('Video kesilemedi. Lütfen tekrar deneyin.'));
  recorder.onstop=()=>{cleanup();if(failure){reject(failure);return}const clip=new Blob(chunks,{type:mime.split(';')[0]});clip.size?resolve(clip):reject(new Error('Kanca dosyası oluşturulamadı.'))};
  recorder.start(100);draw();
  timer=setInterval(()=>{progress('Kanca kesiliyor · %'+Math.min(100,Math.round((video.currentTime-start)/(end-start)*100)));if(video.currentTime>=end||video.ended)stop()},16);
  timeout=setTimeout(()=>stop(new Error('Kesme tamamlanamadı. Sekmeyi açık tutarak tekrar deneyin.')),(end-start+20)*1000);
  video.play().catch(()=>stop(new Error('Video oynatılamadı. Tekrar deneyin.')));
 });
}

