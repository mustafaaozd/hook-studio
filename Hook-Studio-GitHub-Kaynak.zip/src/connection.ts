export const SUPABASE_URL='https://llwinuyajmuxfrhlgasm.supabase.co';
export const PUBLIC_KEY='sb_publishable_Af3pfedzivRbXJr1tIUbCA_xtB02ekZ';
const KEY='hook-studio-session-v1';
type Session={access_token:string;refresh_token:string;expires_at:number;expires_in:number};
export function session():Session|null {try{return JSON.parse(sessionStorage.getItem(KEY)||'null')}catch{return null}}
let refreshing:Promise<string>|null=null;
async function auth(path:string,body:unknown){const r=await fetch(SUPABASE_URL+'/auth/v1/'+path,{method:'POST',headers:{apikey:PUBLIC_KEY,'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw new Error('Giriş yapılamadı. E-posta ve şifrenizi kontrol edin.');sessionStorage.setItem(KEY,JSON.stringify({...d,expires_at:Math.floor(Date.now()/1000)+d.expires_in}));return d.access_token as string}
export async function login(email:string,password:string){await auth('token?grant_type=password',{email,password})}
async function bearer(){const s=session();if(!s)return '';if(s.expires_at>Date.now()/1000+60)return s.access_token;if(!refreshing)refreshing=auth('token?grant_type=refresh_token',{refresh_token:s.refresh_token}).catch(e=>{sessionStorage.removeItem(KEY);throw e}).finally(()=>{refreshing=null});return refreshing}
export async function logout(){const s=session();sessionStorage.removeItem(KEY);if(s)await fetch(SUPABASE_URL+'/auth/v1/logout?scope=local',{method:'POST',headers:{apikey:PUBLIC_KEY,Authorization:'Bearer '+s.access_token}}).catch(()=>{});location.reload()}
export async function cloudApi(token:string|undefined,path:string,method='GET',body?:any){
 const [route,query='']=path.split('?');const params=new URLSearchParams(query);params.set('path',route);
 const headers:Record<string,string>={apikey:PUBLIC_KEY};if(token)headers['x-report-token']=token;else{const jwt=await bearer();if(jwt)headers.Authorization='Bearer '+jwt;}
 if(body&&!(body instanceof FormData))headers['Content-Type']='application/json';
 const r=await fetch(SUPABASE_URL+'/functions/v1/hook-studio-api?'+params,{method,headers,body:body instanceof FormData?body:body?JSON.stringify(body):undefined});
 const d=await r.json();if(!r.ok)throw new Error(d.error||'Bağlantı kurulamadı. Lütfen tekrar deneyin.');return d;
}
