import React,{useState} from 'react';
import {createRoot} from 'react-dom/client';
import Studio from './studio';
import {login,session,logout} from './connection';
function App(){
 const token=new URLSearchParams(location.hash.slice(1)).get('r')||undefined;
 const [signed,setSigned]=useState(!!session()),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 if(token||signed)return <>{!token&&<button className="signout" onClick={logout}>Çıkış yap</button>}<Studio token={token}/></>;
 return <main className="gate"><div className="logomark">h.</div><h1>İçerik stüdyonuz.</h1><p>Markalarınızın kancaları ve reklamları, tek yerde.</p><form className="login-form" onSubmit={async e=>{e.preventDefault();setBusy(true);setError('');try{await login(email.trim(),password);setPassword('');setSigned(true)}catch(e:any){setError(e.message)}finally{setBusy(false)}}}><label>E-posta<input type="email" value={email} autoComplete="username" onChange={e=>setEmail(e.target.value)} required/></label><label>Şifre<input type="password" value={password} autoComplete="current-password" onChange={e=>setPassword(e.target.value)} required/></label><button className="primary" disabled={busy}>{busy?'Giriş yapılıyor…':'Yönetici girişi'}</button>{error&&<p className="error" role="alert">{error}</p>}<small>Yalnızca yetkili yönetici hesabıyla giriş yapılabilir. Müşterileriniz kendilerine özel bağlantıyı kullanır.</small></form></main>;
}
createRoot(document.getElementById('root')!).render(<App/>);
