# Hook Studio v3

## Kullanım
Hook-Studio-v3-Onizleme.html dosyasını güncel bir tarayıcıda açın. Bu dosya aynı uygulama arayüzünün yerel deneme sürümüdür; internet sunucusuna dosya yüklemez. Yeni marka, logo, reklam görseli/video, kanca kesme, sıralama ve silme akışları içerir. Kayıtlar IndexedDB destekleniyorsa bu tarayıcıya kaydedilir. Gizli mod, yerel dosya kısıtlamaları veya tarayıcı verilerini silmek kayıtları kaybettirebilir. Bu dosyayı müşteriye göndererek verilerinizi paylaşamazsınız.

## Yeni yapı
- Tarih ve rapor dönemi kaldırıldı. Markanın tüm içerikleri iki sekmede görünür: Kanca / Reklam.
- Yönetici sol panelden marka ekler, ad/logo düzenler ve müşteriye özel bağlantıyı kopyalar. Telefonda panel Markalar düğmesiyle açılır.
- Başlıkta logo yükleme alanı görünür; müşteri başlığında kayıtlı logo gösterilir.
- Kartlar noktalı tutamaktan fare veya dokunmayla taşınır. Ok düğmeleri ve klavye okları da aynı işlemi yapar. Sıralama her marka ve sekme için ayrı kaydedilir.
- Sil düğmesi onaydan sonra içerik kaydını ve dosyalarını kaldırır.
- Kanca eklerken veya mevcut kancayı düzenlerken başlangıç/bitiş saniyesi seçilir. Örneğin 10 saniyelik videonun 4–7 saniyeleri 3 saniyelik kanca olarak kaydedilir. Orijinal korunur.
- Reklamlara MP4/WebM/MOV video veya JPG/PNG/WebP görsel yüklenir. Çok iyi / İyi / Ortalama seçimi hem video hem görsel reklamlarda bulunur.
- İçerik sayısı, en iyi kanca ve ortalama gibi özet kutuları yoktur.
- Sistem yazı tipleri, yumuşak köşeler, kompakt kartlar ve iOS tarzı sekme kontrolü kullanılır. Masaüstünde dört/üç, telefonda iki sütuna uyarlanır.

## Müşteri paylaşımı
Canlı uygulamada Kopyala aynı marka bağlantısını tekrar kullanır. Bağlantıyı yenile işlemi onay ister ve eski bağlantıyı geçersiz kılar. Müşteri bağlantısı yalnızca ilgili markaya erişir; yönetim paneli yoktur, sunucu düzenleme/silme/sıralama isteklerini reddeder.

Yerel önizlemede müşteri bağlantısı alanı bilinçli olarak pasiftir. Geçerli müşteri bağlantısı için bulut yayını gerekir. Önceki yayın yetkilendirme engeli nedeniyle bu sürüm henüz yayınlanmadı. Gerçek bir müşteri paylaşım bağlantısı oluşturulmadı.

## Kaynak ve kurulum
Hook-Studio-v3-Kaynak.zip güncel uygulama kaynaklarını içerir. Mevcut Sites proje kimliği korunmuştur; yeni proje oluşturmayın. GitHub deposu henüz oluşturulmadı. GitHub Pages tek başına uygulamanın sunucu, D1 ve R2 işlevlerini çalıştırmaz.

Node.js >=22.13.0 ve npm gerekir:
1. npm ci
2. npm run build
3. README.md içindeki D1 yönergelerine göre drizzle/*.sql migration dosyalarını sırasıyla uygulayın; eski migration'ları yeniden çalıştırmayın. Üretimde Sites yayın süreci migration'ları uygular.
4. Yerel .dev.vars dosyasına OWNER_EMAIL="seedy@sites.test" yazın; Git'e eklemeyin.
5. npm run dev
6. /signin-with-chatgpt?return_to=/ ile yerel yönetici girişi.

Üretimde OWNER_EMAIL gerçek yönetici e-postasıdır. Kimlik başlıkları Sites'ın güvenilir oturum katmanına dayanır; farklı sunucuya taşırken kimlik doğrulama kurulmalıdır. İçerikler D1, dosyalar özel R2 deposunda tutulur. Tarayıcıya depolama erişim anahtarı verilmez.

## Sınırlar ve doğrulama
- Video dosyası en fazla 50 MB; reklam görseli en fazla 10 MB; logo en fazla 1 MB.
- Bir kanca en fazla 60 saniyedir; videonun herhangi bir bölümünden seçilebilir.
- Kesme, tarayıcının canvas / MediaRecorder / Web Audio özellikleriyle gerçek zamanlı yapılır. Güncel Safari/Chrome/Edge hedeflenmiştir; işlem sırasında sekmeyi açık tutun. Telefonda H.264 MP4 en yaygın uyumluluk seçeneğidir.
- TypeScript, üretim derlemesi ve API testleri geçti. Testler görsel reklam, sıralama, marka izolasyonu, silme, sabit bağlantı/iptal ve 4–7 saniyelik yeni klibin kaydını/orijinalin korunmasını kapsar.
- API testleri bellek SQLite ve sahte R2 üzerinde çalışır; gerçek videonun görsel/işitsel kalitesini doğrulamaz.
- Önceki tarayıcı izni reddi nedeniyle bu oturumda görsel veya gerçek kesme uçtan uca tarayıcı testi yapılmadı. Telefon üzerinde doğrulanmış çalışma iddiası yoktur.

