'use client';
import {useEffect,useRef,useState,type RefObject} from 'react';
import {Scissors,Play,ZoomIn} from 'lucide-react';
type Props={video:RefObject<HTMLVideoElement|null>;src:string;duration:number;start:number;end:number;disabled:boolean;onStart:(n:number)=>void;onEnd:(n:number)=>void;onPreview:()=>void;onSeek:()=>void};
const time=(n:number)=>{n=Number.isFinite(n)?Math.max(0,n):0;return Math.floor(n/60).toString().padStart(2,'0')+':'+(n%60).toFixed(1).padStart(4,'0')};
const clamp=(n:number,min:number,max:number)=>Math.max(min,Math.min(max,n));
export default function TrimTimeline({video,src,duration,start,end,disabled,onStart,onEnd,onPreview,onSeek}:Props){
 const [current,setCurrent]=useState(0),[zoom,setZoom]=useState(1),[frames,setFrames]=useState<string[]>([]);
 const track=useRef<HTMLDivElement>(null),drag=useRef<'start'|'end'|'seek'|null>(null);
 const valid=Number.isFinite(duration)&&duration>0,d=valid?duration:1,gap=Math.min(.1,d);
 const pct=(n:number)=>clamp(n/d*100,0,100);
 useEffect(()=>{setCurrent(0);setZoom(1)},[src]);
 useEffect(()=>{const v=video.current;if(!v)return;let raf=0;
  const sync=()=>setCurrent(v.currentTime||0);
  const loop=()=>{sync();if(!v.paused)raf=requestAnimationFrame(loop)};
  const play=()=>{cancelAnimationFrame(raf);loop()};
  v.addEventListener('play',play);v.addEventListener('timeupdate',sync);v.addEventListener('seeked',sync);v.addEventListener('loadedmetadata',sync);sync();if(!v.paused)play();
  return()=>{cancelAnimationFrame(raf);v.removeEventListener('play',play);v.removeEventListener('timeupdate',sync);v.removeEventListener('seeked',sync);v.removeEventListener('loadedmetadata',sync)};
 },[src,duration,video]);
 useEffect(()=>{setFrames([]);if(!valid||!src)return;let cancelled=false;
  const v=document.createElement('video');v.muted=true;v.playsInline=true;v.preload='auto';
  const wait=(event:string)=>new Promise<void>((resolve,reject)=>{const done=()=>{clearTimeout(timeout);v.removeEventListener('error',bad);resolve()};const bad=()=>{clearTimeout(timeout);v.removeEventListener(event,done);reject(new Error('thumbnail'))};const timeout=setTimeout(()=>{v.removeEventListener(event,done);v.removeEventListener('error',bad);reject(new Error('thumbnail timeout'))},5000);v.addEventListener(event,done,{once:true});v.addEventListener('error',bad,{once:true})});
  (async()=>{try{const ready=wait('loadeddata');v.src=src;await ready;const canvas=document.createElement('canvas');canvas.width=90;canvas.height=120;const ctx=canvas.getContext('2d');if(!ctx)return;const images:string[]=[];
   for(let i=0;i<10&&!cancelled;i++){const point=Math.min(duration-.01,(i+.5)/10*duration);const done=wait('seeked');v.currentTime=Math.max(0,point);await done;if(cancelled)return;const scale=Math.max(90/v.videoWidth,120/v.videoHeight),w=v.videoWidth*scale,h=v.videoHeight*scale;ctx.drawImage(v,(90-w)/2,(120-h)/2,w,h);images.push(canvas.toDataURL('image/jpeg',.6))}
   if(!cancelled)setFrames(images);
  }catch{/* The ruler stays usable if frame extraction is unsupported. */}})();
  return()=>{cancelled=true;v.removeAttribute('src');v.load()};
 },[src,duration,valid]);
 function seek(n:number){const v=video.current;if(!v)return;onSeek();v.pause();v.currentTime=clamp(n,0,d);setCurrent(clamp(n,0,d))}
 function setBoundary(mode:'start'|'end',n:number){if(mode==='start'){const value=clamp(n,Math.max(0,end-60),Math.max(0,end-gap));onStart(value);seek(value)}else{const value=clamp(n,start+gap,Math.min(d,start+60));onEnd(value);seek(value)}}
 function pointer(x:number){const r=track.current?.getBoundingClientRect();if(!r)return;const n=clamp((x-r.left)/r.width*d,0,d);if(drag.current==='start'||drag.current==='end')setBoundary(drag.current,n);else seek(n)}
 function markStart(){const n=clamp(current,0,d-gap);onStart(n);if(end<=n||end-n>60)onEnd(Math.min(d,n+3));seek(n)}
 function markEnd(){const n=clamp(current,gap,d);onEnd(n);if(start>=n||n-start>60)onStart(Math.max(0,n-3));seek(n)}
 return <div className="trim-editor capcut-trim">
 <div className="trim-heading"><Scissors size={16}/><b>Kancanı seç</b><span>{Math.max(0,end-start).toFixed(1)} sn</span></div>
 <div className="timeline-status"><span className="current-time"><i/>{time(current)}</span><span>/ {time(valid?duration:0)}</span><label className="zoom-control"><ZoomIn size={14}/><select aria-label="Zaman çizelgesini yakınlaştır" value={zoom} disabled={disabled} onChange={e=>setZoom(Number(e.target.value))}>{[1,2,4,8].map(z=><option value={z} key={z}>{z}×</option>)}</select></label></div>
 <div className="timeline-scroll"><div style={{width:zoom*100+'%'}} className="timeline-inner">
 <div className="timeline-ruler">{Array.from({length:5*zoom+1},(_,i)=><span key={i} style={{left:i/(5*zoom)*100+'%'}}>{time(d*i/(5*zoom))}</span>)}</div>
 <div ref={track} className={'film-track '+(disabled?'locked':'')} onPointerDown={e=>{if(disabled||!valid)return;e.preventDefault();const handle=(e.target as HTMLElement).closest<HTMLElement>('[data-boundary]');drag.current=(handle?.dataset.boundary as 'start'|'end')||'seek';e.currentTarget.setPointerCapture(e.pointerId);pointer(e.clientX)}} onPointerMove={e=>{if(drag.current&&e.currentTarget.hasPointerCapture(e.pointerId))pointer(e.clientX)}} onPointerUp={e=>{if(e.currentTarget.hasPointerCapture(e.pointerId))e.currentTarget.releasePointerCapture(e.pointerId);drag.current=null}} onPointerCancel={()=>{drag.current=null}}>
 <div className="film-frames" aria-hidden="true">{frames.length?frames.map((f,i)=><img src={f} alt="" key={i}/>):Array.from({length:10},(_,i)=><span key={i}/>)}</div>
 <div className="trim-shade left" style={{width:pct(start)+'%'}}/><div className="trim-shade right" style={{width:(100-pct(end))+'%'}}/>
 <div className="trim-selection" style={{left:pct(start)+'%',width:Math.max(0,pct(end)-pct(start))+'%'}}/>
 {(['start','end'] as const).map(mode=><button key={mode} type="button" data-boundary={mode} className={'trim-handle '+mode} style={{left:pct(mode==='start'?start:end)+'%'}} role="slider" aria-label={mode==='start'?'Kanca başlangıcı':'Kanca bitişi'} aria-valuemin={mode==='start'?Math.max(0,end-60):start+gap} aria-valuemax={mode==='start'?end-gap:Math.min(d,start+60)} aria-valuenow={mode==='start'?start:end} aria-valuetext={time(mode==='start'?start:end)} disabled={disabled||!valid} onKeyDown={e=>{const v=mode==='start'?start:end;if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();setBoundary(mode,v+(e.key==='ArrowLeft'?-1:1)*(e.shiftKey?1:.1))}}}><span/></button>)}
 <div className="red-playhead" style={{left:pct(current)+'%'}} aria-hidden="true"><i/></div>
 </div></div></div>
 <label className="sr-only">Video konumu<input type="range" min={0} max={d} step=".01" value={current} disabled={disabled||!valid} onChange={e=>seek(Number(e.target.value))}/></label>
 <div className="mark-buttons"><button type="button" disabled={disabled||!valid} onClick={markStart}>Buradan başlat</button><button type="button" disabled={disabled||!valid} onClick={markEnd}>Burada bitir</button></div>
 <div className="two trim-values"><label>Başlangıç<input type="number" min={0} max={Math.max(0,end-gap)} step=".1" value={Number(start.toFixed(2))} disabled={disabled} onChange={e=>{if(e.target.value!=='')setBoundary('start',Number(e.target.value))}}/></label><label>Bitiş<input type="number" min={start+gap} max={Math.min(d,start+60)} step=".1" value={Number(end.toFixed(2))} disabled={disabled} onChange={e=>{if(e.target.value!=='')setBoundary('end',Number(e.target.value))}}/></label></div>
 <button type="button" className="preview-selection" disabled={disabled||!valid} onClick={onPreview}><Play size={14}/> Seçili {Math.max(0,end-start).toFixed(1)} saniyeyi izle</button>
 <p className="muted">Görüntülere dokunarak ilerleyin. Mavi tutamaçları sürükleyerek kesilecek alanı seçin.</p>
 </div>;
}

