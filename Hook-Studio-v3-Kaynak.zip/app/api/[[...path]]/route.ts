import { env } from 'cloudflare:workers';
const json=(v:unknown,status=200)=>Response.json(v,{status,headers:{'Cache-Control':'no-store','X-Robots-Tag':'noindex, nofollow','Referrer-Policy':'no-referrer'}});
const fail=(s:number,m:string):never=>{throw Object.assign(new Error(m),{status:s})};
const rand=()=>Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');
const hash=async(s:string)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s))),n=>n.toString(16).padStart(2,'0')).join('');
const str=(v:unknown,max=200)=>typeof v==='string'&&v.length<=max?v:fail(400,'Geçersiz metin.');
async function handle(req:Request){try{
 const db=env.DB!,bucket=env.BUCKET!;if(!db||!bucket)return json({error:'Depolama bağlantısı hazır değil.'},503);
 const u=new URL(req.url),p=u.pathname.replace(/^\/api\/?/,'').split('/');
 const ownerEmail=(env as unknown as Record<string,string>).OWNER_EMAIL;
 const email=req.headers.get('oai-authenticated-user-email');
 const token=req.headers.get('x-report-token')||u.searchParams.get('token');
 const admin=!token&&!!ownerEmail&&email?.toLowerCase()===ownerEmail.toLowerCase()&&!!req.headers.get('oai-authenticated-user-id');
 const shared=token&&/^[a-f0-9]{64}$/.test(token)?await db.prepare('SELECT * FROM brands WHERE token=?').bind(await hash(token)).first<any>():null;
 if(p[0]==='session')return json({admin,signedIn:!!email});
 if(!admin&&!shared)return json({error:'Bu rapora erişilemiyor. Geçerli bir bağlantı kullanın.'},403);
 if(req.method!=='GET'){
   if(!admin)return json({error:'Yalnızca yönetici düzenleyebilir.'},403);
   if(req.headers.get('origin')!==u.origin)return json({error:'Geçersiz istek kaynağı.'},403);
 }
 if(req.method==='GET'&&p[0]==='data'){
  const brands=admin?(await db.prepare('SELECT id,name,logo,description,created FROM brands ORDER BY created DESC').all()).results:[{id:shared.id,name:shared.name,logo:shared.logo,description:shared.description,created:shared.created}];
  const videos=admin?(await db.prepare('SELECT * FROM videos ORDER BY created DESC').all()).results:(await db.prepare('SELECT * FROM videos WHERE brand_id=? ORDER BY created DESC').bind(shared.id).all()).results;
  return json({brands,videos,admin});
 }
 if(p[0]==='media'&&req.method==='GET'){
   const video=await db.prepare('SELECT * FROM videos WHERE id=?').bind(p[1]).first<any>();
   if(!video||(!admin&&video.brand_id!==shared.id))return json({error:'Video bulunamadı.'},404);
   const key=p[2]==='original'?video.original:video.clip;
   const range=req.headers.get('range');const obj=await bucket.get(key,range?{range:req.headers}:{});
   if(!obj)return json({error:'Video bulunamadı.'},404);
   const h=new Headers({'Cache-Control':'private, no-store','Accept-Ranges':'bytes','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'});obj.writeHttpMetadata(h);
   const rr=obj.range as {offset?:number,length?:number}|undefined;
   if(rr&&rr.offset!==undefined&&rr.length!==undefined){h.set('Content-Range', 'bytes '+rr.offset+'-'+(rr.offset+rr.length-1)+'/'+obj.size);h.set('Content-Length',String(rr.length));return new Response(obj.body,{status:206,headers:h});}
   h.set('Content-Length',String(obj.size));return new Response(obj.body,{headers:h});
 }
 if(p[0]==='brands'&&req.method==='DELETE'){
   const b=await req.json() as any,id=str(b.id);
   if(!await db.prepare('SELECT id FROM brands WHERE id=?').bind(id).first())fail(404,'Marka bulunamadı.');
   const rows=(await db.prepare('SELECT original,clip FROM videos WHERE brand_id=?').bind(id).all()).results;
   const keys=[...new Set(rows.flatMap((v:any)=>[String(v.original),String(v.clip)]))];
   for(let i=0;i<keys.length;i+=100)await bucket.delete(keys.slice(i,i+100));
   await db.batch([db.prepare('DELETE FROM videos WHERE brand_id=?').bind(id),db.prepare('DELETE FROM brands WHERE id=?').bind(id)]);
   return json({ok:true});
 }
 if(p[0]==='brands'&&req.method==='POST'){
   const b=await req.json() as any,name=str(b.name).trim(),logo=str(b.logo||'',1500000),description=str(b.description||'',1000);
   if(!name)fail(400,'Marka adını yazın.');if(logo&&!/^data:image\/(png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(logo))fail(400,'PNG, JPG veya WebP logo kullanın.');
   if(b.id){await db.prepare('UPDATE brands SET name=?,logo=?,description=? WHERE id=?').bind(name,logo,description,str(b.id)).run();return json({ok:true});}
   const id=crypto.randomUUID();await db.prepare('INSERT INTO brands(id,name,logo,description,token,created) VALUES(?,?,?,?,?,?)').bind(id,name,logo,description,await hash(rand()),new Date().toISOString()).run();return json({id});
 }

 if(p[0]==='share'){
   if(!admin)fail(403,'Yalnızca yönetici bağlantıyı yönetebilir.');
   const b=req.method==='GET'?{id:u.searchParams.get('id'),rotate:false}:await req.json() as any;
   const existing=await db.prepare('SELECT id,share_key FROM brands WHERE id=?').bind(str(b.id)).first<any>();if(!existing)fail(404,'Marka bulunamadı.');
   if(req.method==='GET')return json({url:existing.share_key?u.origin+'/r/'+existing.share_key:''});
   if(req.method!=='POST')fail(405,'Geçersiz işlem.');
   if(existing.share_key&&!b.rotate)return json({url:u.origin+'/r/'+existing.share_key});
   const t=rand();await db.prepare('UPDATE brands SET token=?,share_key=? WHERE id=?').bind(await hash(t),t,b.id).run();return json({url:u.origin+'/r/'+t});
 }
 if(p[0]==='reorder'&&req.method==='POST'){
   const b=await req.json() as any;const brand=str(b.brand),kind=str(b.kind);
   if(!['hook','ad'].includes(kind)||!Array.isArray(b.ids)||b.ids.length>2000||b.ids.some((id:unknown)=>typeof id!=='string')||new Set(b.ids).size!==b.ids.length)fail(400,'Geçersiz sıralama.');
   const rows=(await db.prepare('SELECT id FROM videos WHERE brand_id=? AND kind=?').bind(brand,kind).all()).results;
   if(rows.length!==b.ids.length||rows.some((r:any)=>!b.ids.includes(r.id)))fail(409,'İçerikler değişti. Sayfayı yenileyip tekrar deneyin.');
   if(b.ids.length)await db.batch(b.ids.map((id:string,i:number)=>db.prepare('UPDATE videos SET position=? WHERE id=? AND brand_id=? AND kind=?').bind(i,id,brand,kind)));
   return json({ok:true});
 }
 if(p[0]==='videos'&&req.method==='POST'){
   if(Number(req.headers.get('content-length')||0)>65*1024*1024)fail(413,'Toplam yükleme 65 MB sınırını aşıyor.');
   const f=await req.formData();
   if(p[1]&&p[2]==='clip'){
     const current=await db.prepare('SELECT * FROM videos WHERE id=?').bind(p[1]).first<any>();
     if(!current||current.kind!=='hook')fail(404,'Kanca bulunamadı.');
     const clip=f.get('clip'),start=Number(f.get('start')),end=Number(f.get('end')),name=str(f.get('name')).trim(),hook=Number(f.get('hook'));
     if(!(clip instanceof File)||!['video/mp4','video/webm'].includes(clip.type)||!clip.size||clip.size>50*1024*1024||!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start||end-start>60.1||!name||!Number.isFinite(hook)||hook<0||hook>100)fail(400,'Kesim aralığını ve video bilgilerini kontrol edin.');
     const key=current.brand_id+'/'+current.id+'/clip-'+crypto.randomUUID();
     await bucket.put(key,(clip as File).stream(),{httpMetadata:{contentType:(clip as File).type}});
     try{await db.prepare('UPDATE videos SET clip=?,start=?,end=?,name=?,hook=? WHERE id=?').bind(key,start,end,name,hook,current.id).run();}catch(e){await bucket.delete(key);throw e;}
     if(current.clip!==current.original)await bucket.delete(current.clip);
     return json({ok:true});
   }
   const kind=str(f.get('kind')||'hook'),performance=str(f.get('performance')||'');
   if(!['hook','ad'].includes(kind)||(kind==='ad'&&!['cok_iyi','iyi','ortalama'].includes(performance)))fail(400,'Geçersiz içerik türü veya reklam performansı.');
   const original=f.get('original');if(!(original instanceof File)||!original.size)fail(400,'Dosya seçin.');
   const imageTypes=['image/png','image/jpeg','image/webp'],videoTypes=['video/mp4','video/webm','video/quicktime'];
   const isImage=imageTypes.includes((original as File).type);
   if(isImage){
     if(kind!=='ad'||(original as File).size>10*1024*1024)fail(400,'Görseller yalnızca reklamlara eklenebilir; en fazla 10 MB olabilir.');
     const h=new Uint8Array(await (original as File).slice(0,12).arrayBuffer());
     const ok=(original as File).type==='image/png'?h[0]===137&&h[1]===80&&h[2]===78&&h[3]===71:(original as File).type==='image/jpeg'?h[0]===255&&h[1]===216&&h[2]===255:String.fromCharCode(...h.slice(0,4))==='RIFF'&&String.fromCharCode(...h.slice(8,12))==='WEBP';
     if(!ok)fail(400,'Görsel biçimi geçersiz.');
   }else if(!videoTypes.includes((original as File).type)||(original as File).size>50*1024*1024)fail(400,'En fazla 50 MB MP4, WebM veya MOV seçin.');
   const brand=str(f.get('brand')),name=str(f.get('name')).trim(),hook=kind==='ad'?0:Number(f.get('hook')),start=kind==='ad'?0:Number(f.get('start')),end=isImage?0:Number(f.get('end')),category=str(f.get('category')||''),note=str(f.get('note')||'',3000);
   if(!name||!Number.isFinite(hook)||hook<0||hook>100||!Number.isFinite(start)||!Number.isFinite(end)||start<0||(!isImage&&end<=start)||(kind==='hook'&&end-start>60.1))fail(400,'Dosya bilgilerini ve kesim aralığını kontrol edin.');
   if(!await db.prepare('SELECT id FROM brands WHERE id=?').bind(brand).first())fail(404,'Marka bulunamadı.');
   const clip=kind==='ad'?original:f.get('clip');
   if(!(clip instanceof File)||!clip.size||(kind==='hook'&&(!videoTypes.includes(clip.type)||clip.size>50*1024*1024)))fail(400,'Kanca videosu eksik veya geçersiz.');
   const id=crypto.randomUUID(),okey=brand+'/'+id+'/original',ckey=kind==='ad'?okey:brand+'/'+id+'/clip';
   try{await bucket.put(okey,(original as File).stream(),{httpMetadata:{contentType:(original as File).type}});
     if(kind==='hook')await bucket.put(ckey,(clip as File).stream(),{httpMetadata:{contentType:(clip as File).type}});
     await db.prepare('INSERT INTO videos(id,brand_id,name,hook,category,note,original,clip,start,end,created,kind,performance,media_type,position) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)').bind(id,brand,name,hook,category,note,okey,ckey,start,end,new Date().toISOString(),kind,kind==='ad'?performance:'',isImage?'image':'video',Date.now()).run();
   }catch(e){await bucket.delete([okey,ckey]);throw e;}
   return json({id});
 }
 if(p[0]==='videos'&&req.method==='PATCH'){
   const b=await req.json() as any;const current=await db.prepare('SELECT kind FROM videos WHERE id=?').bind(str(b.id)).first<any>();if(!current)fail(404,'İçerik bulunamadı.');
   const performance=current.kind==='ad'?str(b.performance):'';if(current.kind==='ad'&&!['cok_iyi','iyi','ortalama'].includes(performance))fail(400,'Reklam performansı seçin.');
   const name=str(b.name).trim(),hook=current.kind==='ad'?0:Number(b.hook);if(!name||!Number.isFinite(hook)||hook<0||hook>100)fail(400,'Ad ve oranı kontrol edin.');
   await db.prepare('UPDATE videos SET name=?,hook=?,performance=? WHERE id=?').bind(name,hook,performance,str(b.id)).run();return json({ok:true});
 }
 if(p[0]==='videos'&&req.method==='DELETE'){
   const b=await req.json() as any;const v=await db.prepare('SELECT * FROM videos WHERE id=?').bind(str(b.id)).first<any>();if(!v)fail(404,'Video bulunamadı.');await db.prepare('DELETE FROM videos WHERE id=?').bind(b.id).run();await bucket.delete([v.original,v.clip]);return json({ok:true});
 }
 return json({error:'İşlem bulunamadı.'},404);
 }catch(e:any){console.error('API error',e?.status||500);return json({error:e.status?e.message:'İşlem tamamlanamadı. Lütfen tekrar deneyin.'},e.status||500)}}
export const GET=handle,POST=handle,PATCH=handle,DELETE=handle;

