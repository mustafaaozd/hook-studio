import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Hook Studio — İçeriğin ilk etkisi",
  description: "Markanıza özel video ve kanca performans raporları.",
  robots: { index: false, follow: false },
  referrer: "no-referrer",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="tr">
      <body className="antialiased">{children}</body>
    </html>
  );
}
