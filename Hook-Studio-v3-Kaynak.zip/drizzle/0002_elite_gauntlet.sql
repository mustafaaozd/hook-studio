ALTER TABLE `videos` ADD `kind` text DEFAULT 'hook' NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `performance` text DEFAULT '' NOT NULL;