CREATE TABLE `brands` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`logo` text DEFAULT '' NOT NULL,
	`description` text DEFAULT '' NOT NULL,
	`token` text NOT NULL,
	`created` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `brands_token_unique` ON `brands` (`token`);--> statement-breakpoint
CREATE TABLE `videos` (
	`id` text PRIMARY KEY NOT NULL,
	`brand_id` text NOT NULL,
	`name` text NOT NULL,
	`hook` real NOT NULL,
	`category` text NOT NULL,
	`note` text DEFAULT '' NOT NULL,
	`original` text NOT NULL,
	`clip` text NOT NULL,
	`start` real NOT NULL,
	`end` real NOT NULL,
	`created` text NOT NULL,
	FOREIGN KEY (`brand_id`) REFERENCES `brands`(`id`) ON UPDATE no action ON DELETE no action
);
