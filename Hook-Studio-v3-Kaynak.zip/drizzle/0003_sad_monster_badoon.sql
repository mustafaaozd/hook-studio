ALTER TABLE `brands` ADD `share_key` text;--> statement-breakpoint
ALTER TABLE `videos` ADD `position` real DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `videos` ADD `media_type` text DEFAULT 'video' NOT NULL;