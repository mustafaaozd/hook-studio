type LocalState={brands:any[];videos:any[];assets:Record<string,Blob>};
const objectUrls=new Map<string,string>();
let memory:LocalState={brands:[{id:'example-brand',name:'Örnek Marka',logo:'',description:''}],videos:[],assets:{}};
const openDb=new Promise<IDBDatabase|null>(resolve=>{try{const req=indexedDB.open('hook-studio-v3-preview',1);req.onupgradeneeded=()=>req.result.createObjectStore('state');req.onsuccess=()=>resolve(req.result);req.onerror=()=>resolve(null)}catch{resolve(null)}});
async function read(){const db=await openDb;if(!db)return memory;return new Promise<LocalState>(resolve=>{const r=db.transaction('state').objectStore('state').get('main');r.onsuccess=()=>resolve(r.result||memory);r.onerror=()=>resolve(memory)})}
async function write(s:LocalState){memory=s;const db=await openDb;if(!db)return;await new Promise<void>((resolve,reject)=>{const tx=db.transaction('state','readwrite');tx.objectStore('state').put(s,'main');tx.oncomplete=()=>resolve();tx.onerror=()=>reject(new Error('Tarayıcı depolaması doldu. Daha küçük bir dosya seçin.'))})}
export function localMedia(v:any,original=false){return objectUrls.get(original?v.original:v.clip)||''}
export async function localApi(path:string,method='GET',body?:any):Promise<any>{
 const state=await read(),[route,id,action]=path.split('?')[0].split('/');
 if(route==='share'){if(method==='GET')return {url:''};throw new Error('Bu yerel önizlemedir. Müşteri bağlantısı uygulama yayına alındığında oluşturulabilir.')}
 if(route==='data'){
  for(const [key,blob] of Object.entries(state.assets))if(!objectUrls.has(key))objectUrls.set(key,URL.createObjectURL(blob));
  for(const [key,url] of objectUrls)if(!state.assets[key]){URL.revokeObjectURL(url);objectUrls.delete(key)}
  return {brands:state.brands,videos:state.videos,admin:true};
 }
 if(route==='brands'){
  if(method==='DELETE'){
   for(const item of state.videos.filter(v=>v.brand_id===body.id)){delete state.assets[item.original];delete state.assets[item.clip]}
   state.videos=state.videos.filter(v=>v.brand_id!==body.id);state.brands=state.brands.filter(b=>b.id!==body.id);
   await write(state);return {ok:true};
  }
  if(body.id){const b=state.brands.find(b=>b.id===body.id);Object.assign(b,body)}else{body={...body,id:crypto.randomUUID()};state.brands.push(body)}
  await write(state);return {id:body.id};
 }
 if(route==='reorder'){body.ids.forEach((id:string,i:number)=>{const v=state.videos.find(v=>v.id===id);if(v)v.position=i});await write(state);return {ok:true}}
 if(route==='videos'){
  if(method==='DELETE'){const v=state.videos.find(v=>v.id===body.id);if(v){delete state.assets[v.original];delete state.assets[v.clip]}state.videos=state.videos.filter(v=>v.id!==body.id)}
  else if(method==='PATCH'){const v=state.videos.find(v=>v.id===body.id);Object.assign(v,body)}
  else if(action==='clip'){const v=state.videos.find(v=>v.id===id);if(v.clip!==v.original)delete state.assets[v.clip];v.clip=id+'/clip/'+crypto.randomUUID();state.assets[v.clip]=body.get('clip');v.start=Number(body.get('start'));v.end=Number(body.get('end'));v.name=body.get('name');v.hook=Number(body.get('hook'))}
  else {const id=crypto.randomUUID(),original=body.get('original') as File,kind=body.get('kind'),isImage=original.type.startsWith('image/');const v={id,brand_id:body.get('brand'),name:body.get('name'),hook:Number(body.get('hook')),start:Number(body.get('start')),end:Number(body.get('end')),kind,performance:body.get('performance'),media_type:isImage?'image':'video',original:id+'/original',clip:kind==='ad'?id+'/original':id+'/clip',position:Date.now(),created:new Date().toISOString()};state.assets[v.original]=original;if(kind==='hook')state.assets[v.clip]=body.get('clip');state.videos.push(v)}
  await write(state);return {ok:true};
 }
 throw new Error('Önizleme işlemi bulunamadı.');
}

